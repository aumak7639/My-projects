<?php

define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'iniya');
define('DB_HOST', 'localhost');
define('BASE_URL', 'http://localhost/projects/iniya/api/v1/');
